
from tensorflow.keras.preprocessing.image import ImageDataGenerator
import os
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Conv2D, MaxPooling2D, GlobalAveragePooling2D, Dense, Dropout, GlobalAveragePooling2D
import matplotlib.pyplot as plt
from tensorflow.keras.metrics import Precision, Recall


# Read the dataset
train_dir = 'C:/Users/jgj/Desktop/PythonApplication1/PythonApplication1/CancerDataClassification/train2'
validation_dir = 'C:/Users/jgj/Desktop/PythonApplication1/PythonApplication1/CancerDataClassification/val2'

# Checking directories
if not os.path.exists(train_dir):
    raise FileNotFoundError(f"Training directory {train_dir} not found")
if not os.path.exists(validation_dir):
    raise FileNotFoundError(f"Validation directory {validation_dir} not found")

train_datagen = ImageDataGenerator(
    rescale=1./255,
    rotation_range=40,       # Random rotation between 0 and 40 degrees
    width_shift_range=0.2,   # Random horizontal shift
    height_shift_range=0.2,  # Random vertical shift
    shear_range=0.2,         # Shear transformation
    zoom_range=0.2,          # Random zoom
    horizontal_flip=True,    # Random horizontal flip
    fill_mode='nearest'      # Strategy for filling in newly created pixels
)
validation_datagen = ImageDataGenerator(rescale=1./255)

# Loading the data and handling potential issues
try:
    train_generator = train_datagen.flow_from_directory(
        train_dir,
        target_size=(150, 150),
        batch_size=20,
        class_mode='binary'
    )

    print(train_generator)

    validation_generator = validation_datagen.flow_from_directory(
        validation_dir,
        target_size=(150, 150),
        batch_size=20,
        class_mode='binary'
    )
    print(validation_generator)
except ValueError as e:
    print("Error loading data:", e)
    raise

# Define the model

model = Sequential([
    Conv2D(32, (3, 3), activation='relu', input_shape=(150, 150, 3)),
    MaxPooling2D(2, 2),
    Conv2D(64, (3, 3), activation='relu'),
    MaxPooling2D(2, 2),
    Conv2D(128, (3, 3), activation='relu'),
    MaxPooling2D(2, 2),
    GlobalAveragePooling2D(),  # Replacing Flatten with Global Average Pooling
    Dropout(0.5),              # Adding dropout for regularization
    Dense(512, activation='relu'),
    Dense(1, activation='sigmoid')
])

#model.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'])
model.compile(
    optimizer='adam', 
    loss='binary_crossentropy', 
    metrics=['accuracy', Precision(name='precision'), Recall(name='recall')]
)


history = model.fit(
    train_generator,
    epochs=100,
    validation_data=validation_generator
)

acc = history.history['accuracy']
val_acc = history.history['val_accuracy']
loss = history.history['loss']
val_loss = history.history['val_loss']

epochs_range = range(100)

plt.figure(figsize=(8, 5))
plt.plot(epochs_range, acc, label='Training Accuracy')
plt.plot(epochs_range, val_acc, label='Validation Accuracy')
plt.legend(loc='lower right')
plt.title('Training and Validation Accuracy')

plt.figure(figsize=(8, 5))
plt.plot(epochs_range, loss, label='Training Loss')
plt.plot(epochs_range, val_loss, label='Validation Loss')
plt.legend(loc='upper right')
plt.title('Training and Validation Loss')
plt.show()

precision = history.history['precision']
val_precision = history.history['val_precision']
recall = history.history['recall']
val_recall = history.history['val_recall']

# Now plotting all metrics
plt.figure(figsize=(8, 5))
plt.plot(epochs_range, precision, label='Training Precision')
plt.plot(epochs_range, val_precision, label='Validation Precision')
plt.legend(loc='lower right')
plt.title('Training and Validation Precision')

# Subplot for recall
plt.figure(figsize=(8, 5))
plt.plot(epochs_range, recall, label='Training Recall')
plt.plot(epochs_range, val_recall, label='Validation Recall')
plt.legend(loc='lower right')
plt.title('Training and Validation Recall')

plt.tight_layout()
plt.show()

